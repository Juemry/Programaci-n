﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tp1Programación.Model;

namespace Tp1Programación
{
    public partial class frmSecundario : Form
    {
        public string Nombre2 { get; set; }
        public frmSecundario()
        {
            InitializeComponent();
        }
        


        private void bttnCargar_Click_1(object sender, EventArgs e)
        {
           

        }
       
    }
}
 