﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tp1Programación.Model
{
    public class Alumno
    {
        public string Nombre { get; set; }

        public Alumno()
        {
            
        }
        
    }
}
